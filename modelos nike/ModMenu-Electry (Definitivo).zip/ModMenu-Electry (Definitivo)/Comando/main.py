import pyautogui as pg, time as tm 

funcionando = True

while(funcionando):
    respuesta = input("Que deseas hacer(a para activar, d para desactivar): ")
    if(respuesta == "a"):
        cantidad = int(input("cuantos clicks: "))
        for i in range(cantidad):
            pg.click()
            tm.sleep(12)
            pass
    elif (respuesta == "d"):
        print("Cerrado con exito!.")
        print("Diseñado por TatoDesgin-Electry")
        funcionando = False


